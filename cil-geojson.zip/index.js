var mysql = require('mysql');

// Importing express module
const express = require('express');
const app = express();

app.use(express.json());


app.post('/', (req, res) => {
  const { username, password } = req.body;
  const { authorization } = req.headers;
  res.send({
    username,
    password,
    authorization,
  });
});


app.listen(3000, () => {
  console.log('Our express server is up on port 3000');
});

var con = mysql.createConnection({
  host: '20.219.146.102',
  user: 'root',
  password: 'Sg9aVUBUCAMy',
  database: 'ciladmin'
});

con.connect(function(err) {
  if (err) throw err;
  con.query("SELECT * FROM Dumpers", function(err, result, fields) {
    if (err) throw err;
    console.log(result);
  });
});